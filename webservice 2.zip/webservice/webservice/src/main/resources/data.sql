insert into user_details(birth_date,id,name) values(current_date(),1,'deepali');
insert into user_details(birth_date,id,name) values(current_date(),2,'kartik');
insert into user_details(birth_date,id,name) values(current_date(),3,'aish');
insert into user_details(birth_date,id,name) values(current_date(),4,'monal');
insert into user_details(birth_date,id,name) values(current_date(),5,'tush');

insert into post_details(id,description,user_id) values(11,'need to learn AWS',1);
insert into post_details(id,description,user_id) values(12,'need to learn devops',1);
insert into post_details(id,description,user_id) values(13,'need to learn multi cloud',1);
insert into post_details(id,description,user_id) values(14,'need to learn kubernate',2);
insert into post_details(id,description,user_id) values(15,'need to learn docker',2);
