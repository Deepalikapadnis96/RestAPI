package com.rest.webservices.webservice.users;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import jakarta.validation.Valid;

@RestController
public class UserController {
	private UserService userService;
	private UserRepository userRepository;
	private PostRepository postRepository;

	public UserController(UserService userService, UserRepository userRepository, PostRepository postRepository) {
		this.userService = userService;
		this.userRepository = userRepository;
		this.postRepository = postRepository;
	}

	@GetMapping("/users")
	public List<User> retriveAllUser() {
		return userRepository.findAll();
		// return userService.findAll();

	}

//entityModel is used to add link in api
	@GetMapping("/users/{id}")
	public EntityModel<Optional<User>> retriveOneUser(@PathVariable int id) {
		// User findOne = userService.findOne(id);
		Optional<User> findById = userRepository.findById(id);
		if (findById == null)
			throw new UserNotFoundException("id::" + id);
		EntityModel<Optional<User>> entityModel = EntityModel.of(findById);
		WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retriveAllUser());
		entityModel.add(linkTo.withRel("all-Users"));
		return entityModel;
	}

	@DeleteMapping("/users/{id}")
	public void deleteOneUser(@PathVariable int id) {
		userRepository.deleteById(id);
	}

	@GetMapping("/users/{id}/post")
	public List<Post> retrivePostForUser(@PathVariable int id) {
		Optional<User> user = userRepository.findById(id);
		if (user == null)
			throw new UserNotFoundException("id::" + id);
		return user.get().getPost();
	}

	@PostMapping("/users")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) {
		User save = userRepository.save(user);

		// just to show the message of url in postman
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(save.getId())
				.toUri();
		return ResponseEntity.created(location).build();

	}

	@PostMapping("/users/{id}/post")
	public ResponseEntity<Object> createPostForUser(@PathVariable int id, @Valid @RequestBody Post post) {
		Optional<User> user = userRepository.findById(id);
		if (user.isEmpty())
			throw new UserNotFoundException("id::" + id);
		post.setUser(user.get());
		Post save = postRepository.save(post);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(save.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}
	
}