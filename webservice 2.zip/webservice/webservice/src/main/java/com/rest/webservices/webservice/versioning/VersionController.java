package com.rest.webservices.webservice.versioning;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {
	// ----------------------URI VERSIONING-------------------
	@GetMapping("v1/person")
	public PersonV1 versionOne() {
		return new PersonV1("deepali");
	}

	@GetMapping("v2/person")
	public PersonV2 versionTwo() {
		return new PersonV2(new Name("deepali", "kapadnis"));
	}
	// ----------------------REQUEST PARAMETER VERSIONING-------------------

	@GetMapping(path = "/person", params = "version=1")
	public PersonV1 RequestParameterv1() {
		return new PersonV1("deepali");
	}

	@GetMapping(path = "/person", params = "version=2")
	public PersonV2 RequestParameterv2() {
		return new PersonV2(new Name("deepali", "kapadnis"));
	}
	// ----------------------CUSTOM-HEADER VERSIONING-------------------

	// http://localhost:8080/person/header
	// in header add key=HEADER-VERSION,value=1
	@GetMapping(path = "/person/header", headers = "HEADER-VERSION=1")
	public PersonV1 RequestParameterv1Header() {
		return new PersonV1("deepali");
	}

	@GetMapping(path = "/person/header", headers = "HEADER-VERSION=2")
	public PersonV2 RequestParameterv2Header() {
		return new PersonV2(new Name("deepali", "kapadnis"));
	}

	// ----------------------MEDIA TYPE VERSIONING/ ACCEPT HEADER-------------------
	// http://localhost:8080/person/accept ,key=Accept,
	// value=application/vnd.company.app-v1+json
	@GetMapping(path = "/person/accept", produces = "application/vnd.company.app-v1+json")
	public PersonV1 RequestParameterv1Accept() {
		return new PersonV1("deepali");
	}

	@GetMapping(path = "/person/accept", produces = "application/vnd.company.app-v2+json")
	public PersonV2 RequestParameterv2Accept() {
		return new PersonV2(new Name("deepali", "kapadnis"));
	}

}
