package com.rest.webservices.webservice.users;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;


@Component
public class UserService {

	// public List<User> findAll(){

	// public User save(User user){

	// public User findOne(int id){
	private static int UserCount = 0;
	public static List<User> users = new ArrayList<>();
	static {
		users.add(new User(UserCount++, "deepali", LocalDate.now().minusYears(26), null));
		users.add(new User(UserCount++, "monal", LocalDate.now().minusYears(27), null));
		users.add(new User(UserCount++, "nilima", LocalDate.now().minusYears(28), null));
		users.add(new User(UserCount++, "neha", LocalDate.now().minusYears(30), null));
	}

	public List<User> findAll() {
		return users;
	}

	public User save(User user) {
		user.setId(UserCount++);
		users.add(user);
		return user;
	}

	public User findOne(int id) {
		// if we put any other id will thr exception
		// return users.stream().filter(user ->
		// user.getId().equals(id)).findFirst().get();
		return users.stream().filter(user -> user.getId().equals(id)).findFirst().orElse(null);
	}

	public void deleteById(int id) {
		// if we put any other id will thr exception
		// return users.stream().filter(user ->
		// user.getId().equals(id)).findFirst().get();
		Predicate<?super User> p= user->user.getId().equals(id);
		users.removeIf(p);
		//users.removeIf(user -> user.getId().equals(id));
	}
}
