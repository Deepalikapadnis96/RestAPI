package com.rest.webservices.webservice.versioning;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class PersonV2 {
private Name name;
}
