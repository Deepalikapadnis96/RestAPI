package com.rest.webservices.webservice.testurl;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	private MessageSource messageSource;

	public Controller(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@RequestMapping(method = RequestMethod.GET, path = "/test")
	public String data() {
		return "test";
	}

	@RequestMapping(method = RequestMethod.GET, path = "/test/test1")
	public test1Bean data1() {
		return new test1Bean("test");
	}

	// for lang
	@RequestMapping(method = RequestMethod.GET, path = "/test/lang")
	public String lang() {
		Locale locale=LocaleContextHolder.getLocale();
		System.out.println(locale);
		return messageSource.getMessage("good.morning.message", null, locale);
 
	}

	// url=/test/1---->/test/{id}
	@RequestMapping(method = RequestMethod.GET, path = "/test/test1/{name}")
	public test1Bean data2(@PathVariable String name) {
		return new test1Bean(String.format("test %s", name));
	}
}
