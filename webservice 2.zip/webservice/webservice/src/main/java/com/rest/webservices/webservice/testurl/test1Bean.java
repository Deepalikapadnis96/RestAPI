package com.rest.webservices.webservice.testurl;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class test1Bean {
	private String message;

}
